<h1>User Login</h1>
<form action="/user" method="POST">
	<?php echo csrf_field(); ?>
	<input type="text" name="user" placeholder="username"><br>
	<input type="password" name="password" placeholder="password"><br>
	<button type="submit">Login</button>
	

</form><?php /**PATH D:\New folder\laravelsession\blog\resources\views/login.blade.php ENDPATH**/ ?>